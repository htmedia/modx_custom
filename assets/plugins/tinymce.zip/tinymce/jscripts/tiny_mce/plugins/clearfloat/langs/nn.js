// UK lang variables

tinyMCE.addI18n('nn.clearfloat', {
	button_desc : 'Flow below floated elements'
});
