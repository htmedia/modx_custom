// UK lang variables

tinyMCE.addI18n('ja.clearfloat', {
	button_desc : 'Flow below floated elements'
});
