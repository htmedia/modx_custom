// UK lang variables

tinyMCE.addI18n('es.clearfloat', {
	button_desc : 'Flow below floated elements'
});
