// UK lang variables

tinyMCE.addI18n('da.clearfloat', {
	button_desc : 'Flow below floated elements'
});
