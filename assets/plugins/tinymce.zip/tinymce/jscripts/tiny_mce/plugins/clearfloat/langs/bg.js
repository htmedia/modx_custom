// UK lang variables

tinyMCE.addI18n('bg.clearfloat', {
	button_desc : 'Flow below floated elements'
});
