// UK lang variables

tinyMCE.addI18n('cs.clearfloat', {
	button_desc : 'Flow below floated elements'
});
