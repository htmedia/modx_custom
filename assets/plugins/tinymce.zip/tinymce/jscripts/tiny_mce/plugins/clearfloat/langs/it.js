// UK lang variables

tinyMCE.addI18n('it.clearfloat', {
	button_desc : 'Flow below floated elements'
});
