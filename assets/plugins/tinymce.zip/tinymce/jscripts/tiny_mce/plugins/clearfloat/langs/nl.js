// UK lang variables

tinyMCE.addI18n('nl.clearfloat', {
	button_desc : 'Flow below floated elements'
});
