// UK lang variables

tinyMCE.addI18n('fa.clearfloat', {
	button_desc : 'Flow below floated elements'
});
