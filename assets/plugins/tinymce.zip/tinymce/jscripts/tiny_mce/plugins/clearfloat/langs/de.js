// UK lang variables

tinyMCE.addI18n('de.clearfloat', {
	button_desc : 'Flow below floated elements'
});
