tinyMCE.addI18n('nl.template_dlg',{
title:"Sjablonen",
label:"Sjabloon",
desc_label:"Beschrijving",
desc:"Voorgedefinieerd sjabloon invoegen",
select:"Selecteer een sjabloon",
preview:"Voorbeeld",
warning:"Waarschuwing: het bijwerken van een sjabloon met een andere kan het verlies van informatie tot gevolg hebben.",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"Januari,Februari,Maart,April,Mei,Juni,Juli,Augustus,September,Oktober,November,December",
months_short:"Jan,Feb,Mar,Apr,Mei,Jun,Jul,Aug,Sep,Okt,Nov,Dec",
day_long:"Zondag,Maandag,Dinsdag,Woensdag,Donderdag,Vrijdag,Zaterdag,Zondag",
day_short:"zo,ma,di,wo,do,vr,za,zo"
});