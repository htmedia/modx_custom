tinyMCE.addI18n('pl.advhr_dlg',{
width:"Szeroko\u015B\u0107",
size:"Wysoko\u015B\u0107",
noshade:"Bez cienia"
});