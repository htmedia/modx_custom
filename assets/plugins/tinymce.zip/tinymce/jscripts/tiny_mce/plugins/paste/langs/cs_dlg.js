tinyMCE.addI18n('cs.paste_dlg',{
text_title:"Pou\u017Eijte CTRL+V pro vlo\u017Een\u00ED textu do okna.",
text_linebreaks:"Zachovat zalamov\u00E1n\u00ED \u0159\u00E1dk\u016F",
word_title:"Pou\u017Eijte CTRL+V pro vlo\u017Een\u00ED textu do okna."
});